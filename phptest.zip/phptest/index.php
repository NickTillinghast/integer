<?php 
// this is the db info from adding onto my shell via terminal

$db_user = 'nick';
$db_password = '123456';
$db_name = 'cordphp';
$db_host = 'localhost';

// connecting to db 

$mysqli = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($mysqli ->connect_errno) {
    echo "Connect failed: " . $mysqli ->connect_error;
    exit();

}
echo "Connected Successfully";

// this is the actual table I inserted via the terminal 

// mysql> CREATE TABLE users(
//   id INT AUTO_INCREMENT,
//   first_name VARCHAR(100),
//   last_name VARCHAR(100,)
//   email VARCHAR(75),
//   PRIMARY KEY(id)
//    );
// I then checked and verified using mysql workbench and my terminal.


// selecting all users from table

$query = "SELECT * FROM users";

// selecting first name column from users

$query = "SELECT first_name FROM users";


if (mysqli_query($mysqli, $query)) {
  echo "Query was successful";

}
// printing out the query results

if ($result = mysql_query($mysqli, $query)) {
  $row = mysqli_fetch_array($result);

  print_r($row);
}
// example of creating a table in php.   

// $people_table = 
// "CREATE TABLE IF NOT EXISTS people (
//     ID bigint (20) UNSIGNED NOT NULL AUTO_INCREMENT,
//     name VARCHAR NOT NULL,
//     age INT NOT NULL,
//     email VARCHAR NOT NULL,
//     PRIMARY KEY (ID)
//     )";

// if ($mysqli->query($people) === true) {
//     printf('Table people successfully created.\n');
// }
?>